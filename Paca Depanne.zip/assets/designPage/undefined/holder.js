<!doctype html>
<html lang="en" translate="no">
  <head>
    <meta charset="UTF-8" />
    <!-- Google Tag Manager -->
    <script>
      const env = 'prod'
      const enable = env === 'prod'
      if (enable) {
        ;(function (w, d, s, l, i) {
          w[l] = w[l] || []
          w[l].push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' })
          const f = d.getElementsByTagName(s)[0]
          const j = d.createElement(s)
          const dl = l != 'dataLayer' ? `&l=${l}` : ''
          j.async = true
          j.src = `https://www.googletagmanager.com/gtm.js?id=${i}${dl}`
          f.parentNode.insertBefore(j, f)
        })(window, document, 'script', 'dataLayer', 'GTM-T6TKLPF2')
      }
    </script>
    <!-- End Google Tag Manager -->
    <link rel="icon" href="https://cdn.sketchflow.ai/sketch-flow-icon.png" />
    <link rel="preload" href="/src/assets/images/landing-page/bg-one.png" as="image" />
    <link rel="preload" href="https://cdn.sketchflow.ai/assets/home_spark_bg-w4UKrVd-.png" as="image" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>AI Design to Code: Build Web & Apps Faster | Sketchflow.ai</title>
    <meta
      name="keywords"
      content="AI design tool, AI code generation, design to code, interactive prototypes, UI to code, web & app builder, MVP builder, rapid product development"
    />
    <meta
      name="description"
      content="Go from idea to live product in minutes. Sketchflow's AI generates stunning designs, creates interactive demos, and exports production-ready code for web and apps."
    />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="@sketchflow_ai" />
    <meta name="twitter:title" content="Sketchflow: AI Design â Live Demo â Clean Code ð" />
    <meta
      name="twitter:description"
      content="Your entire product journey, supercharged by AI. Generate beautiful UIs for web & apps in seconds. Instantly preview them as interactive demos. Export the code and launch. It's that simple."
    />
    <meta name="twitter:image" content="https://www.sketchflow.ai/logo.png" />

    <meta property="og:title" content="Sketchflow: AI-powered Design, Live Prototypes & Instant Code" />
    <meta
      property="og:description"
      content="Design with the power of AI. Sketchflow instantly generates stunning interfaces and user flows for your website or app. Preview your creation as a fully interactive prototype, then export clean code with a single click. Your entire product workflow, accelerated."
    />
    <meta property="og:url" content="https://www.sketchflow.ai/" />
    <meta property="og:image" content="https://www.sketchflow.ai/sketchflow-og-image.png" />
    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="Sketchflow.ai" />
    <script type="module" crossorigin src="https://cdn.sketchflow.ai/assets/index.B33jch93-1763089278051.js"></script>
    <link rel="modulepreload" crossorigin href="https://cdn.sketchflow.ai/assets/dep-BF69SXpx.js">
    <link rel="stylesheet" crossorigin href="https://cdn.sketchflow.ai/assets/index-CJzJP8UO.css">
    <script type="module">import.meta.url;import("_").catch(()=>1);(async function*(){})().next();if(location.protocol!="file:"){window.__vite_is_modern_browser=true}</script>
    <script type="module">!function(){if(window.__vite_is_modern_browser)return;console.warn("vite: loading legacy chunks, syntax error above and the same error below should be ignored");var e=document.getElementById("vite-legacy-polyfill"),n=document.createElement("script");n.src=e.src,n.onload=function(){System.import(document.getElementById('vite-legacy-entry').getAttribute('data-src'))},document.body.appendChild(n)}();</script>
  </head>
  <body>
    <div id="app"></div>
    <!-- Google Tag Manager (noscript) -->
    <noscript
      ><iframe
        src="https://www.googletagmanager.com/ns.html?id=GTM-T6TKLPF2"
        height="0"
        width="0"
        style="display: none; visibility: hidden"
      ></iframe
    ></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <script src="https://cdnjs.cloudflare.com/polyfill/v3/polyfill.min.js?version=4.8.0?features=AbortController,Array.from,Array.isArray,Array.prototype.copyWithin,Array.prototype.entries,Array.prototype.every,Array.prototype.fill,Array.prototype.filter,Array.prototype.flat,Array.prototype.flatMap,Array.prototype.find,Array.prototype.findIndex,Array.prototype.forEach,Array.prototype.includes,Array.prototype.indexOf,Array.prototype.keys,Array.prototype.lastIndexOf,Array.prototype.map,Array.prototype.reduce,Array.prototype.some,Array.prototype.sort,Array.prototype.values,ArrayBuffer,ArrayBuffer.isView,atob,Blob,console,CustomEvent,DataView,Date.now,Date.prototype.toISOString,document,Document,Element,es2019,Event,EventSource,fetch,Float32Array,Float64Array,Function.prototype.bind,getComputedStyle,globalThis,innerHeight,innerWidth,Int16Array,Int32Array,Int8Array,IntersectionObserver,Intl,JSON,localStorage,Map,Math.hypot,Math.trunc,modernizr:es5object,modernizr:es6string,MutationObserver,Number.isFinite,Number.isInteger,Number.isNaN,Number.MAX_SAFE_INTEGER,Number.parseFloat,Number.parseInt,Object.assign,Object.entries,Object.freeze,Object.fromEntries,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.is,Object.isExtensible,Object.isFrozen,Object.preventExtensions,Object.setPrototypeOf,Object.values,pageXOffset,pageYOffset,Promise,Promise.prototype.finally,queueMicrotask,Reflect,Reflect.apply,Reflect.construct,Reflect.defineProperty,Reflect.deleteProperty,Reflect.get,Reflect.getOwnPropertyDescriptor,Reflect.getPrototypeOf,Reflect.has,Reflect.ownKeys,Reflect.set,RegExp.prototype.flags,requestAnimationFrame,ResizeObserver,Set,String.fromCodePoint,String.prototype.codePointAt,String.prototype.matchAll,String.prototype.normalize,String.prototype.padStart,String.prototype.trim,Symbol,Symbol.asyncIterator,Symbol.for,Symbol.iterator,Symbol.keyFor,Symbol.prototype.description,Symbol.replace,Symbol.split,Symbol.toPrimitive,Symbol.toStringTag,Symbol.unscopables,Uint16Array,Uint32Array,Uint8Array,Uint8ClampedArray,URL,URLSearchParams,WeakMap,WeakSet,XMLHttpRequest"></script>
    <script nomodule>!function(){var e=document,t=e.createElement("script");if(!("noModule"in t)&&"onbeforeload"in t){var n=!1;e.addEventListener("beforeload",(function(e){if(e.target===t)n=!0;else if(!e.target.hasAttribute("nomodule")||!n)return;e.preventDefault()}),!0),t.type="module",t.src=".",e.head.appendChild(t),t.remove()}}();</script>
    <script nomodule crossorigin id="vite-legacy-polyfill" src="https://cdn.sketchflow.ai/assets/polyfills-legacy.QBVQqlKo-1763089278051.js"></script>
    <script nomodule crossorigin id="vite-legacy-entry" data-src="https://cdn.sketchflow.ai/assets/index-legacy.CxiEr5CR-1763089278051.js">System.import(document.getElementById('vite-legacy-entry').getAttribute('data-src'))</script>
  </body>
</html>
